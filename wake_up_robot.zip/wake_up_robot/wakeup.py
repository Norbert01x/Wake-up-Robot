import cv2
import os
import RPi.GPIO as GPIO
import time

GPIO.setwarnings(False)
GPIO.setmode(GPIO.BOARD)

faceCascade = cv2.CascadeClassifier("haarcascade_frontalface_alt.xml")
eyeCascade = cv2.CascadeClassifier("haarcascade_eye_tree_eyeglasses.xml")

GPIO.setup(3,GPIO.OUT)
GPIO.setup(5,GPIO.OUT)
GPIO.setup(7,GPIO.OUT)

pan = GPIO.PWM(3,50)
tilt = GPIO.PWM(5,50)
hand = GPIO.PWM(7,50)

pan.start(0)
tilt.start(0)
hand.start(0)

cap = cv2.VideoCapture(0)



angle_t=30
tilt.ChangeDutyCycle(2 + (angle_t / 18))
time.sleep(1)
angle_p=140
pan.ChangeDutyCycle(2 + (angle_p / 18))
time.sleep(5)


while angle_t<=90:
    angle_t=angle_t+1
    tilt.ChangeDutyCycle(2 + (angle_t / 18))
    time.sleep(0.03)

tilt.ChangeDutyCycle(0)

while angle_p>=70:
    angle_p=angle_p-1
    pan.ChangeDutyCycle(2 + (angle_p / 18))
    time.sleep(0.03)

pan.ChangeDutyCycle(0)




os.system('espeak --stdout "hello" | aplay')
time.sleep(1)
os.system('espeak -s 130 --stdout "My job is not to let you sleep" | aplay')




while 1:
    ret, img = cap.read()
    if ret:
        frame = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
      
        faces = faceCascade.detectMultiScale(
            frame,
            scaleFactor=1.1,
            minNeighbors=5,
            minSize=(30, 30),
           
        )
     if len(faces) > 0:
        for (x, y, w, h) in faces:
            
            frame_tmp = img[faces[0][1]:faces[0][1] + faces[0][3], faces[0][0]:faces[0][0] + faces[0][2]:1, :]
            frame = frame[faces[0][1]:faces[0][1] + faces[0][3], faces[0][0]:faces[0][0] + faces[0][2]:1]
            eyes = eyeCascade.detectMultiScale(
                frame,
                scaleFactor=1.3,
                minNeighbors=5,
                minSize=(30, 30),
                
            )
            if len(eyes) == 0:

                aa = 1
                while aa <= 2:
                    aa = aa + 1
                    os.system('espeak --stdout "Wake up" | aplay')
                    angle = 130
                    hand.ChangeDutyCycle(2 + (angle / 18))
                    time.sleep(0.5)
                    angle = 60
                    hand.ChangeDutyCycle(2 + (angle / 18))
                    time.sleep(0.3)
                hand.ChangeDutyCycle(0)
                time.sleep(1)


